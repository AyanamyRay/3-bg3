import { createContext, useContext, useEffect, useState, useMemo, useRef } from 'react';
import { Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import { Canvas, useFrame, useLoader } from '@react-three/fiber';
import { Environment } from '@react-three/drei';
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader';
import { fetchProducts, fetchProduct, fetchHeroes, placeOrder, rollD20, USERS } from './api';
import { categories } from './products';
import './App.css';

/* ---------- Словарь ---------- */
const dict = {
  ru: { home:'Главная', shop:'Товары', about:'О нас', heroes:'О персонажах', cart:'Корзина',
    search:'Поиск...', sort:'Сортировка', byName:'По имени', priceAsc:'Дешевле', priceDesc:'Дороже',
    addCart:'В корзину', buy:'Оформить заказ', total:'Итого', empty:'Корзина пуста',
    description:'Описание', stats:'Характеристики', back:'Назад', loading:'Загрузка...',
    orderPlaced:'Заказ оформлен! Спасибо, искатель приключений.',
    aboutTitle:'О нашем магазине', heroesTitle:"Герои Baldur's Gate 3",
    ordering:'Оформляем заказ...', gold:'зол.',
    diceTitle:'Испытание судьбы', diceRules:'Правила броска',
    diceRule1:'Класс сложности (DC): 18',
    diceRule2:'Бросьте D20. Результат 18+ — успех, вы получаете скидку.',
    diceRule3:'Натуральная 1 — критический провал, скидки не будет.',
    diceRule4:'Натуральная 20 — критическая победа, максимальная скидка вашей роли.',
    rollBtn:'Бросить кубик', rolling:'Кубик катится...',
    resultWin:'Успех! Вы получаете скидку', resultLose:'Провал. Скидка не получена',
    critFail:'КРИТИЧЕСКИЙ ПРОВАЛ!', critWin:'КРИТИЧЕСКАЯ ПОБЕДА!',
    applyDiscount:'Применить скидку', decline:'Оставить как есть',
    yourRole:'Ваша роль', maxDiscount:'Максимальная скидка',
    discountApplied:'Скидка применена ко всем товарам!',
    discountDeclined:'Вы отказались от скидки.',
    rollResult:'Результат броска',
    changeUser:'Сменить пользователя',
    cooldownTitle:'Следующий бесплатный бросок через',
    extraRollsLeft:'Дополнительных бросков',
    buyRoll:'Купить бросок за 500 зол.',
    skipTime:'Тестовый режим: пропустить время',
    noRolls:'Нет доступных бросков.' },
  en: { home:'Home', shop:'Shop', about:'About', heroes:'Heroes', cart:'Cart',
    search:'Search...', sort:'Sort', byName:'By name', priceAsc:'Cheapest', priceDesc:'Priciest',
    addCart:'Add to cart', buy:'Checkout', total:'Total', empty:'Cart is empty',
    description:'Description', stats:'Stats', back:'Back', loading:'Loading...',
    orderPlaced:'Order placed! Thank you, adventurer.',
    aboutTitle:'About our shop', heroesTitle:"Heroes of Baldur's Gate 3",
    ordering:'Placing order...', gold:'gold',
    diceTitle:'Trial of Fate', diceRules:'Roll Rules',
    diceRule1:'Difficulty Class (DC): 18',
    diceRule2:'Roll D20. Result 18+ — success, you gain a discount.',
    diceRule3:'Natural 1 — critical fail, no discount.',
    diceRule4:'Natural 20 — critical win, maximum discount for your role.',
    rollBtn:'Roll the dice', rolling:'Dice rolling...',
    resultWin:'Success! You gain a discount', resultLose:'Fail. No discount',
    critFail:'CRITICAL FAIL!', critWin:'CRITICAL WIN!',
    applyDiscount:'Apply discount', decline:'Keep as is',
    yourRole:'Your role', maxDiscount:'Max discount',
    discountApplied:'Discount applied to all items!',
    discountDeclined:'You declined the discount.',
    rollResult:'Roll result',
    changeUser:'Switch user',
    cooldownTitle:'Next free roll in',
    extraRollsLeft:'Extra rolls',
    buyRoll:'Buy a roll for 500 gold',
    skipTime:'Test mode: skip time',
    noRolls:'No rolls available.' },
};

/* ---------- Цитаты ---------- */
const QUOTES = {
  ru: [
    '«Власть не даётся — её берут».',
    '«Судьба — это иллюзия. Есть только выбор».',
    '«Мы все — пешки в чьей-то игре. Пока не станем игроками».',
    '«Тьма не всегда зло. Иногда — просто путь».',
  ],
  en: [
    '"Power is not given — it is taken."',
    '"Destiny is an illusion. There is only choice."',
    '"We are all pawns in someone\'s game. Until we become players."',
    '"Darkness is not always evil. Sometimes — just a path."',
  ],
};
const QUOTE_IDX = {
  ru: Math.floor(Math.random() * QUOTES.ru.length),
  en: Math.floor(Math.random() * QUOTES.en.length),
};

const DAY_MS = 24 * 60 * 60 * 1000;

/* ---------- Финальная поза кубика ---------- */
/* Все броски останавливаются в одном положении — том, что на скриншоте */
const FINAL_POSE = { x: 0.37, y: 1.20, z: 0.35 };

/* ---------- Easing ---------- */
function easeOutCubic(t) {
  return 1 - Math.pow(1 - t, 3);
}

/* ---------- Контекст ---------- */
const AppContext = createContext();
const useApp = () => useContext(AppContext);

export default function App() {
  const [theme, setTheme] = useState('dark');
  const [lang, setLang] = useState('ru');
  const [cart, setCart] = useState([]);
  const [userId, setUserId] = useState('regular');
  const [diceDiscount, setDiceDiscount] = useState(0);

  const [lastRoll, setLastRoll] = useState(() => {
    const v = localStorage.getItem('bg3_lastRoll');
    return v ? Number(v) : 0;
  });
  const [extraRolls, setExtraRolls] = useState(() => {
    const v = localStorage.getItem('bg3_extraRolls');
    return v ? Number(v) : 0;
  });

  useEffect(() => { document.body.className = theme; }, [theme]);
  useEffect(() => { localStorage.setItem('bg3_lastRoll', String(lastRoll)); }, [lastRoll]);
  useEffect(() => { localStorage.setItem('bg3_extraRolls', String(extraRolls)); }, [extraRolls]);

  const user = USERS[userId];

  const addToCart = (p) => setCart(c => {
    const ex = c.find(i => i.id === p.id);
    return ex ? c.map(i => i.id === p.id ? { ...i, qty: i.qty + 1 } : i)
              : [...c, { ...p, qty: 1 }];
  });
  const removeFromCart = (id) => setCart(c => c.filter(i => i.id !== id));

  const getDiscount = (p) => {
    const base = p.discount || 0;
    const total = base + diceDiscount;
    return Math.min(total, user.maxDiscount);
  };
  const getPrice = (p) => {
    const d = getDiscount(p);
    return d ? Math.round(p.price * (1 - d / 100)) : p.price;
  };

  const t = (k) => dict[lang][k];

  const ctx = {
    theme, setTheme, lang, setLang, cart, addToCart, removeFromCart, t,
    userId, setUserId, user, diceDiscount, setDiceDiscount,
    getDiscount, getPrice,
    lastRoll, setLastRoll, extraRolls, setExtraRolls,
  };

  return (
    <AppContext.Provider value={ctx}>
      <header className="header">
        <Link to="/dice" className="logo">
          <span className="dice-icon" />
          <span>BG3 Shop</span>
        </Link>
        <nav>
          <Link to="/">{t('home')}</Link>
          <Link to="/shop">{t('shop')}</Link>
          <Link to="/about">{t('about')}</Link>
          <Link to="/heroes">{t('heroes')}</Link>
          <Link to="/cart">{t('cart')} ({cart.reduce((s, i) => s + i.qty, 0)})</Link>
        </nav>
        <div className="controls">
          <select
            value={userId}
            onChange={e => { setUserId(e.target.value); setDiceDiscount(0); }}
            title={t('changeUser')}
          >
            <option value="regular">{USERS.regular.name[lang]}</option>
            <option value="vip">{USERS.vip.name[lang]}</option>
            <option value="test">{USERS.test.name[lang]}</option>
          </select>
          <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>
          <button onClick={() => setLang(lang === 'ru' ? 'en' : 'ru')}>
            {lang === 'ru' ? 'EN' : 'RU'}
          </button>
        </div>
      </header>

      <main className="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/product/:id" element={<ProductPage />} />
          <Route path="/about" element={<About />} />
          <Route path="/heroes" element={<Heroes />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/dice" element={<Dice />} />
        </Routes>
      </main>

      <footer className="footer">
        <p>© 2025 BG3 Shop — фанатский магазин по Baldur's Gate 3</p>
        <p>Данные: bg3.wiki | Сделано с ❤️ для искателей приключений</p>
      </footer>
    </AppContext.Provider>
  );
}

/* ---------- Главная ---------- */
function Home() {
  const { t, lang } = useApp();
  const quote = QUOTES[lang][QUOTE_IDX[lang]];
  return (
    <section className="hero">
      <h1>{lang === 'ru' ? 'Лавка приключений Фаэруна' : "Adventurer's Shop of Faerûn"}</h1>
      <p>{lang === 'ru'
        ? 'Зелья, клинки и свитки — всё для победы над Абсолютом.'
        : 'Potions, blades and scrolls — all to defeat the Absolute.'}</p>
      <p className="hero-quote">{quote}</p>
      <Link to="/shop" className="btn">{t('shop')}</Link>
    </section>
  );
}

/* ---------- Магазин ---------- */
function Shop() {
  const { t, lang } = useApp();
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [sort, setSort] = useState('name');
  const [cat, setCat] = useState('all');

  useEffect(() => {
    let alive = true;
    fetchProducts().then(data => { if (alive) { setList(data); setLoading(false); } });
    return () => { alive = false; };
  }, []);

  const shown = useMemo(() => {
    let arr = list.filter(p => p.name[lang].toLowerCase().includes(q.toLowerCase()));
    if (cat !== 'all') arr = arr.filter(p => p.cat === cat);
    arr = [...arr].sort((a, b) => {
      if (sort === 'priceAsc')  return a.price - b.price;
      if (sort === 'priceDesc') return b.price - a.price;
      return a.name[lang].localeCompare(b.name[lang]);
    });
    return arr;
  }, [list, q, sort, cat, lang]);

  if (loading) return <div className="loader">{t('loading')}</div>;

  return (
    <section className="shop">
      <h2>{t('shop')} ({shown.length})</h2>
      <div className="filters">
        <input placeholder={t('search')} value={q} onChange={e => setQ(e.target.value)} />
        <select value={sort} onChange={e => setSort(e.target.value)}>
          <option value="name">{t('byName')}</option>
          <option value="priceAsc">{t('priceAsc')}</option>
          <option value="priceDesc">{t('priceDesc')}</option>
        </select>
      </div>
      <div className="cats">
        {categories.map(c => (
          <button key={c.id} className={cat === c.id ? 'active' : ''} onClick={() => setCat(c.id)}>
            {c[lang]}
          </button>
        ))}
      </div>
      <div className="grid">
        {shown.map(p => <Card key={p.id} p={p} />)}
      </div>
    </section>
  );
}

/* ---------- Карточка ---------- */
function Card({ p }) {
  const { t, lang, addToCart, getDiscount, getPrice } = useApp();
  const final = getPrice(p);
  const totalDiscount = getDiscount(p);
  return (
    <div className="card">
      <Link to={`/product/${p.id}`}>
        <img src={p.img} alt={p.name[lang]} />
        <h3>{p.name[lang]}</h3>
      </Link>
      {totalDiscount > 0 && <span className="badge">-{totalDiscount}%</span>}
      <p className="price">
        {final < p.price && <s>{p.price}</s>} <b>{final}</b> {t('gold')}
      </p>
      <button className="btn" onClick={() => addToCart(p)}>{t('addCart')}</button>
    </div>
  );
}

/* ---------- Страница товара ---------- */
function ProductPage() {
  const { id } = useParams();
  const { t, lang, addToCart, getDiscount, getPrice } = useApp();
  const [p, setP] = useState(null);

  useEffect(() => {
    let alive = true;
    fetchProduct(id).then(data => { if (alive) setP(data); });
    return () => { alive = false; };
  }, [id]);

  if (!p) return <div className="loader">{t('loading')}</div>;
  const final = getPrice(p);
  const totalDiscount = getDiscount(p);

  return (
    <section className="product-page">
      <Link to="/shop" className="back">← {t('back')}</Link>
      <div className="product-flex">
        <img src={p.img} alt={p.name[lang]} />
        <div>
          <h1>{p.name[lang]}</h1>
          <p><b>{t('description')}:</b> {p.desc[lang]}</p>
          <p className="price">
            {totalDiscount > 0 && <s>{p.price}</s>} <b>{final}</b> {t('gold')}
            {totalDiscount > 0 && <span className="discount-tag">-{totalDiscount}%</span>}
          </p>
          <h3>{t('stats')}</h3>
          <ul>{Object.entries(p.stats).map(([k, v]) => <li key={k}>{k}: {v}</li>)}</ul>
          <button className="btn" onClick={() => addToCart(p)}>{t('addCart')}</button>
        </div>
      </div>
    </section>
  );
}

/* ---------- О нас ---------- */
function About() {
  const { t, lang } = useApp();
  return (
    <section className="page">
      <h1>{t('aboutTitle')}</h1>
      <p>{lang === 'ru'
        ? "Мы — небольшая гильдия торговцев из Нижнего города Балдурс-Гейта. Продаём снаряжение искателям приключений с самого открытия Врат Балдура."
        : "We are a small merchant guild from the Lower City of Baldur's Gate. We sell gear to adventurers since the city gates first opened."}</p>
      <p>{lang === 'ru'
        ? 'Информация о товарах основана на открытой вики bg3.wiki.'
        : 'Product info is based on the open bg3.wiki.'}</p>
    </section>
  );
}

/* ---------- О персонажах ---------- */
function Heroes() {
  const { t, lang } = useApp();
  const [heroes, setHeroes] = useState([]);

  useEffect(() => {
    let alive = true;
    fetchHeroes().then(data => { if (alive) setHeroes(data); });
    return () => { alive = false; };
  }, []);

  if (!heroes.length) return <div className="loader">{t('loading')}</div>;

  return (
    <section className="page">
      <h1>{t('heroesTitle')}</h1>
      <div className="heroes-grid">
        {heroes.map(h => (
          <article key={h.id} className="hero-card">
            <img src={h.img} alt={h.name[lang]} className="hero-img" />
            <div>
              <h2>{h.name[lang]}</h2>
              <p>{h.bio[lang]}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

/* ---------- Корзина ---------- */
function Cart() {
  const { cart, removeFromCart, t, lang, getPrice } = useApp();
  const navigate = useNavigate();
  const [status, setStatus] = useState('idle');

  const total = cart.reduce((s, i) => s + getPrice(i) * i.qty, 0);

  const checkout = async () => {
    setStatus('loading');
    await placeOrder(cart);
    setStatus('done');
    setTimeout(() => navigate('/'), 2500);
  };

  if (status === 'loading') return <div className="loader">{t('ordering')}</div>;
  if (status === 'done')    return <div className="loader">{t('orderPlaced')}</div>;

  return (
    <section className="page">
      <h1>{t('cart')}</h1>
      {cart.length === 0 ? <p>{t('empty')}</p> : (
        <>
          {cart.map(i => (
            <div key={i.id} className="cart-row">
              <img src={i.img} alt="" width="50" />
              <span>{i.name[lang]} × {i.qty}</span>
              <span><b>{getPrice(i) * i.qty}</b> {t('gold')}</span>
              <button onClick={() => removeFromCart(i.id)}>✕</button>
            </div>
          ))}
          <h2>{t('total')}: {total} {t('gold')}</h2>
          <button className="btn" onClick={checkout}>{t('buy')}</button>
        </>
      )}
    </section>
  );
}

/* ---------- 3D-модель D20 — всегда останавливается в одной позе ---------- */
function DiceModel({ rolling, result }) {
  const geometry = useLoader(STLLoader, '/d20.stl');
  const meshRef = useRef();
  const spinRef = useRef(0.15);
  const stopStartRef = useRef(null);

  // Центрируем и нормируем масштаб
  const centered = useMemo(() => {
    const g = geometry.clone();
    g.center();
    g.computeVertexNormals();
    g.computeBoundingSphere();
    const s = 2 / g.boundingSphere.radius;
    g.scale(s, s, s);
    return g;
  }, [geometry]);

  // Сбрасываем таймер остановки при новом результате
  useEffect(() => {
    if (result) stopStartRef.current = null;
  }, [result]);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Есть результат — плавно останавливаемся в фиксированной позе
    if (result) {
      if (stopStartRef.current === null) {
        stopStartRef.current = state.clock.elapsedTime;
      }

      // Прогресс 0→1 за 1.8 сек с easeOutCubic
      const t = Math.min((state.clock.elapsedTime - stopStartRef.current) / 1.8, 1);
      const ease = easeOutCubic(t);

      meshRef.current.rotation.x += (FINAL_POSE.x - meshRef.current.rotation.x) * ease * Math.min(delta * 6, 1);
      meshRef.current.rotation.y += (FINAL_POSE.y - meshRef.current.rotation.y) * ease * Math.min(delta * 6, 1);
      meshRef.current.rotation.z += (FINAL_POSE.z - meshRef.current.rotation.z) * ease * Math.min(delta * 6, 1);

      // Жёсткая фиксация в конце
      if (t >= 1) {
        meshRef.current.rotation.x = FINAL_POSE.x;
        meshRef.current.rotation.y = FINAL_POSE.y;
        meshRef.current.rotation.z = FINAL_POSE.z;
      }
      return;
    }

    // Ожидание и быстрое вращение во время броска
    const speed = rolling ? 3.5 : 0.15;
    spinRef.current += (speed - spinRef.current) * Math.min(delta * 4, 1);

    meshRef.current.rotation.x += delta * spinRef.current;
    meshRef.current.rotation.y += delta * spinRef.current * 1.3;
    meshRef.current.rotation.z += delta * spinRef.current * 0.6;
  });

  // Светлая зелёная палитра
  const color = useMemo(() => {
    if (!result) return '#7ed957';
    if (result.critFail) return '#3a7a3e';
    if (result.critWin)  return '#b8f2a0';
    if (result.success)  return '#8fdc6c';
    return '#5aaa55';
  }, [result]);

  return (
    <mesh ref={meshRef} geometry={centered} castShadow receiveShadow>
      <meshStandardMaterial
        color={color}
        metalness={0.35}
        roughness={0.4}
        emissive={rolling ? '#a8f080' : result?.critWin ? '#a8f080' : '#000000'}
        emissiveIntensity={rolling ? 0.5 : result?.critWin ? 0.6 : 0}
      />
    </mesh>
  );
}

/* ---------- Страница броска D20 ---------- */
function Dice() {
  const { t, lang, user, userId, diceDiscount, setDiceDiscount,
          lastRoll, setLastRoll, extraRolls, setExtraRolls } = useApp();
  const [rolling, setRolling] = useState(false);
  const [result, setResult] = useState(null);
  const [showNumber, setShowNumber] = useState(false);
  const [applied, setApplied] = useState(false);
  const [declined, setDeclined] = useState(false);

  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const timeLeft = Math.max(0, lastRoll + DAY_MS - now);
  const freeRollReady = timeLeft === 0;
  const canRoll = freeRollReady || extraRolls > 0;
  const isTest = userId === 'test';

  const fmt = (ms) => {
    const s = Math.floor(ms / 1000);
    const h = String(Math.floor(s / 3600)).padStart(2, '0');
    const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
    const ss = String(s % 60).padStart(2, '0');
    return `${h}:${m}:${ss}`;
  };

  const doRoll = async () => {
    if (!canRoll || rolling) return;

    if (freeRollReady) {
      setLastRoll(Date.now());
    } else {
      setExtraRolls(extraRolls - 1);
    }

    setRolling(true);
    setResult(null);
    setShowNumber(false);
    setApplied(false);
    setDeclined(false);

    const res = await rollD20();

    // Ждём, пока кубик плавно доедет до финальной позы, и показываем число
    setTimeout(() => {
      setResult(res);
      setRolling(false);
      // Число — ещё позже, когда кубик точно замер
      setTimeout(() => setShowNumber(true), 600);
    }, 200);
  };

  const applyDiscount = () => {
    if (!result?.success) return;
    const maxD = user.maxDiscount;
    const value = result.critWin ? maxD : Math.round(maxD * 0.6);
    setDiceDiscount(value);
    setApplied(true);
  };

  const buyRoll = () => setExtraRolls(extraRolls + 1);
  const skipTime = () => setLastRoll(0);

  return (
    <section className="dice-page">
      <h1>{t('diceTitle')}</h1>

      <div className="dice-role">
        <p><b>{t('yourRole')}:</b> {user.name[lang]}</p>
        <p><b>{t('maxDiscount')}:</b> {user.maxDiscount}%</p>
        {extraRolls > 0 && <p><b>{t('extraRollsLeft')}:</b> {extraRolls}</p>}
      </div>

      {!freeRollReady && (
        <div className="dice-cooldown">
          <p>{t('cooldownTitle')}: <span className="time">{fmt(timeLeft)}</span></p>
          {isTest && (
            <button className="dice-skip" onClick={skipTime}>{t('skipTime')}</button>
          )}
        </div>
      )}

      <div className="dice-stage">
        <div className="dice-3d-wrap">
          <Canvas
            camera={{ position: [0, 0, 5], fov: 45 }}
            gl={{ alpha: true, antialias: true }}
            dpr={[1, 2]}
          >
            <ambientLight intensity={1.0} />
            <hemisphereLight intensity={0.7} color="#e0ffd0" groundColor="#3a6a30" />
            <directionalLight position={[5, 5, 5]} intensity={1.6} color="#f0ffe4" />
            <directionalLight position={[-5, -3, 2]} intensity={0.9} color="#7ed957" />
            <pointLight position={[0, 0, 4]} intensity={1.4} color="#b8f2a0" />

            <DiceModel rolling={rolling} result={result} />

            <Environment preset="night" />
          </Canvas>

          <button
            className="dice-click-catcher"
            onClick={doRoll}
            disabled={!canRoll || rolling}
            aria-label={t('rollBtn')}
          />

          {showNumber && (
            <div className="dice-overlay-number">{result.roll}</div>
          )}
        </div>

        {rolling && <p className="dice-status">{t('rolling')}</p>}
        {!canRoll && !rolling && <p className="dice-status">{t('noRolls')}</p>}
      </div>

      {!rolling && (
        <div className="dice-buy-wrap">
          <button className="dice-buy" onClick={buyRoll}>{t('buyRoll')}</button>
        </div>
      )}

      {result && (
        <div className={`dice-result ${result.success ? 'success' : 'fail'}`}>
          <h2>
            {result.critFail ? t('critFail')
             : result.critWin ? t('critWin')
             : result.success ? t('resultWin')
             : t('resultLose')}
          </h2>
          <p>{t('rollResult')}: <b>{result.roll}</b> / DC {result.DC}</p>

          {result.success && !applied && !declined && (
            <div className="dice-actions">
              <button className="btn" onClick={applyDiscount}>{t('applyDiscount')}</button>
              <button className="btn btn-ghost" onClick={() => setDeclined(true)}>{t('decline')}</button>
            </div>
          )}
          {applied  && <p className="dice-note">{t('discountApplied')} ({diceDiscount}%)</p>}
          {declined && <p className="dice-note">{t('discountDeclined')}</p>}
        </div>
      )}

      <div className="dice-rules">
        <h3>{t('diceRules')}</h3>
        <ul>
          <li>{t('diceRule1')}</li>
          <li>{t('diceRule2')}</li>
          <li>{t('diceRule3')}</li>
          <li>{t('diceRule4')}</li>
        </ul>
      </div>
    </section>
  );
}