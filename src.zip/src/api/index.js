// Имитация API: задержки, данные, роли, броски D20

const delay = (ms) => new Promise(r => setTimeout(r, ms));

/* ---------- Пользователи ---------- */
export const USERS = {
  regular: { id: 'regular', name: { ru: 'Обычный герой', en: 'Regular Hero' }, maxDiscount: 15 },
  vip:     { id: 'vip',     name: { ru: 'VIP-авантюрист', en: 'VIP Adventurer' }, maxDiscount: 90 },
  test:    { id: 'test',    name: { ru: 'Тестовый режим', en: 'Test Mode' },       maxDiscount: 0  },
};

/* ---------- Товары и герои ---------- */
export async function fetchProducts() {
  await delay(700);
  const { products } = await import('../products.js');
  return products;
}

export async function fetchProduct(id) {
  await delay(400);
  const { products } = await import('../products.js');
  return products.find(p => p.id === Number(id));
}

export async function fetchHeroes() {
  await delay(500);
  const { heroes } = await import('../products.js');
  return heroes;
}

/* ---------- Бросок D20 с пониженным шансом на 18–20 ---------- */
export async function rollD20() {
  await delay(1200);

  // Веса: 18, 19, 20 выпадают в 0.7 раза реже
  const weights = [];
  for (let face = 1; face <= 20; face++) {
    weights.push(face >= 18 ? 0.7 : 1);
  }

  const totalWeight = weights.reduce((s, w) => s + w, 0);
  let r = Math.random() * totalWeight;
  let roll = 1;
  for (let i = 0; i < 20; i++) {
    r -= weights[i];
    if (r <= 0) { roll = i + 1; break; }
  }

  const DC = 18;
  const success = roll >= DC;
  return {
    roll,
    DC,
    success,
    critFail: roll === 1,
    critWin:  roll === 20,
  };
}

/* ---------- Оформление заказа ---------- */
export async function placeOrder(cart) {
  await delay(900);
  const total = cart.reduce((s, i) => {
    const price = i.customPrice ?? (i.discount ? Math.round(i.price * (1 - i.discount / 100)) : i.price);
    return s + price * i.qty;
  }, 0);
  return {
    ok: true,
    orderId: 'BG3-' + Math.floor(Math.random() * 90000 + 10000),
    total,
  };
}